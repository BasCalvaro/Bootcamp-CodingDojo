function muestraSiElNiñoPuedeSubirALaMontañaRusa(est){
    if (est < 52){
        console.log('Lo siento, chico. Tal vez el próximo año')
    }
    if (est >= 52){
        console.log('¡Súbete, chico!')
    }
}

var alturaNiño = 52
ingreso = muestraSiElNiñoPuedeSubirALaMontañaRusa(alturaNiño)